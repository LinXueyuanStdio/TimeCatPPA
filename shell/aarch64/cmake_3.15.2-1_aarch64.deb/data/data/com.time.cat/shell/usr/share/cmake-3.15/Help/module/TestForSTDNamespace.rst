.. cmake-module:: ../../Modules/TestForSTDNamespace.cmake
