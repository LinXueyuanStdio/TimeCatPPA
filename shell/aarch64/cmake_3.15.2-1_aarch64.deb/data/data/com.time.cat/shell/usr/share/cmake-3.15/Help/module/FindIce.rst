.. cmake-module:: ../../Modules/FindIce.cmake
